package lucene;

public class ParseTrecData {

}
